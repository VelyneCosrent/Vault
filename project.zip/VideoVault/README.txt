Buka folder ini dengan Android Studio (Koala atau lebih baru) -> tunggu Gradle sync -> Run.
Min Android 10 (API 29). Tidak membutuhkan izin storage.

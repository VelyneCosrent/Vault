package com.example.videovault

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

/** PIN utama + PIN jebakan (hash SHA-256 + salt) dan penghitung percobaan salah. */
class PinStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("vault_pin", Context.MODE_PRIVATE)
    fun hasPin() = p.contains("h")
    fun hasDecoy() = p.contains("h2")
    fun set(pin: String) = save("s", "h", pin)
    fun setDecoy(pin: String) = save("s2", "h2", pin)
    fun clearDecoy() { p.edit().remove("h2").apply() }
    fun check(pin: String) = ok("s", "h", pin)
    fun checkDecoy(pin: String) = hasDecoy() && ok("s2", "h2", pin)
    var fails: Int
        get() = p.getInt("f", 0)
        set(v) { p.edit().putInt("f", v).apply() }
    var lockUntil: Long
        get() = p.getLong("lu", 0L)
        set(v) { p.edit().putLong("lu", v).apply() }
    private fun save(sk: String, hk: String, pin: String) {
        val salt = UUID.randomUUID().toString()
        p.edit().putString(sk, salt).putString(hk, hash(pin, salt)).apply()
    }
    private fun ok(sk: String, hk: String, pin: String) = hash(pin, p.getString(sk, "") ?: "") == p.getString(hk, null)
    private fun hash(pin: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
}

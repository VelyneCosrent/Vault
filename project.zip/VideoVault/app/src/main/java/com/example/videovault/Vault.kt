package com.example.videovault

import android.content.ContentValues
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.net.URLConnection
import java.security.MessageDigest
import java.util.UUID


/** Video disalin ke folder privat aplikasi (tidak dipindai galeri), lalu file asli dihapus. */
object Vault {
    var decoy = false
    fun dir(c: Context) = File(c.filesDir, if (decoy) "decoy" else "vault").apply {
        mkdirs(); File(this, ".nomedia").createNewFile()
    }

    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.name != ".nomedia" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun displayName(c: Context, uri: Uri): String? =
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    /** @return true jika file asli berhasil dihapus dari galeri. */
    fun hide(c: Context, uri: Uri): Boolean {
        val name = displayName(c, uri) ?: "video_${System.currentTimeMillis()}.mp4"
        val dest = File(dir(c), "${System.currentTimeMillis()}_$name")
        c.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { i.copyTo(it) } }
        return try { DocumentsContract.deleteDocument(c.contentResolver, uri) } catch (e: Exception) { false }
    }

    fun restore(c: Context, f: File) {
        val name = f.name.substringAfter('_')
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, URLConnection.guessContentTypeFromName(name) ?: "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Restored")
        }
        val uri = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        c.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
    }
}

object Stealth {
    private fun alias(c: Context) = ComponentName(c, "com.example.videovault.Launcher")
    fun isHidden(c: Context) = c.packageManager.getComponentEnabledSetting(alias(c)) ==
        PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    fun setHidden(c: Context, hide: Boolean) = c.packageManager.setComponentEnabledSetting(
        alias(c),
        if (hide) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
        PackageManager.DONT_KILL_APP)
    fun codeOk(c: Context) = c.getSharedPreferences("vault_pin", Context.MODE_PRIVATE).getBoolean("code_ok", false)
}

/** Dipanggil saat Anda menekan *#*#8888#*#* di aplikasi Telepon. */
class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.getSharedPreferences("vault_pin", Context.MODE_PRIVATE).edit().putBoolean("code_ok", true).apply()
        c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

package com.example.videovault

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.net.URLConnection
import java.security.MessageDigest
import java.util.UUID

/** Menyimpan PIN sebagai hash SHA-256 + salt (PIN asli tidak disimpan). */
class PinStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("vault_pin", Context.MODE_PRIVATE)
    fun hasPin() = p.contains("h")
    fun set(pin: String) {
        val salt = UUID.randomUUID().toString()
        p.edit().putString("s", salt).putString("h", hash(pin, salt)).apply()
    }
    fun check(pin: String) = hash(pin, p.getString("s", "") ?: "") == p.getString("h", null)
    private fun hash(pin: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }
}

/** Video disalin ke folder privat aplikasi (tidak dipindai galeri), lalu file asli dihapus. */
object Vault {
    fun dir(c: Context) = File(c.filesDir, "vault").apply {
        mkdirs(); File(this, ".nomedia").createNewFile()
    }

    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.name != ".nomedia" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun displayName(c: Context, uri: Uri): String? =
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    /** @return true jika file asli berhasil dihapus dari galeri. */
    fun hide(c: Context, uri: Uri): Boolean {
        val name = displayName(c, uri) ?: "video_${System.currentTimeMillis()}.mp4"
        val dest = File(dir(c), "${System.currentTimeMillis()}_$name")
        c.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { i.copyTo(it) } }
        return try { DocumentsContract.deleteDocument(c.contentResolver, uri) } catch (e: Exception) { false }
    }

    fun restore(c: Context, f: File) {
        val name = f.name.substringAfter('_')
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, URLConnection.guessContentTypeFromName(name) ?: "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Restored")
        }
        val uri = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        c.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
    }
}

package com.example.videovault

import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Bundle
import android.util.Size
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    var unlocked by mutableStateOf(false)
    var skipLock = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blokir screenshot & preview di recent apps
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    val store = remember { PinStore(this) }
                    if (unlocked) VaultScreen(this) else PinScreen(store) { unlocked = true }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); skipLock = false }
    // Kunci otomatis saat aplikasi ditinggalkan (kecuali sedang memilih video)
    override fun onStop() { super.onStop(); if (!skipLock) unlocked = false }
}

@Composable
fun PinScreen(store: PinStore, onOk: () -> Unit) {
    val create = remember { !store.hasPin() }
    var first by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val title = when {
        !create -> "Masukkan PIN"
        first == null -> "Buat PIN baru (4–6 angka)"
        else -> "Ulangi PIN"
    }
    fun submit() {
        if (pin.length < 4) { err = "Minimal 4 angka"; return }
        when {
            !create -> if (store.check(pin)) onOk() else { err = "PIN salah"; pin = "" }
            first == null -> { first = pin; pin = ""; err = "" }
            first == pin -> { store.set(pin); onOk() }
            else -> { err = "PIN tidak sama, ulangi dari awal"; first = null; pin = "" }
        }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🔒 Video Vault", fontSize = 26.sp)
        Spacer(Modifier.height(24.dp))
        Text(title)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(6) { i ->
                Box(Modifier.size(14.dp).clip(CircleShape)
                    .background(if (i < pin.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline))
            }
        }
        Text(err, color = MaterialTheme.colorScheme.error, modifier = Modifier.height(32.dp).padding(top = 8.dp))
        val keys = listOf("1","2","3","4","5","6","7","8","9","⌫","0","OK")
        keys.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { k ->
                    OutlinedButton({
                        err = ""
                        when (k) {
                            "⌫" -> pin = pin.dropLast(1)
                            "OK" -> submit()
                            else -> if (pin.length < 6) pin += k
                        }
                    }, Modifier.padding(vertical = 4.dp).size(76.dp), shape = CircleShape) { Text(k, fontSize = 20.sp) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(act: MainActivity) {
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(Vault.list(act)) }
    var selected by remember { mutableStateOf<File?>(null) }
    var playing by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var hidden by remember { mutableStateOf(Stealth.isHidden(act)) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val notDeleted = withContext(Dispatchers.IO) {
                uris.count { runCatching { !Vault.hide(act, it) }.getOrDefault(true) }
            }
            files = Vault.list(act); busy = false
            val msg = if (notDeleted == 0) "${uris.size} video disembunyikan"
            else "$notDeleted file asli gagal dihapus otomatis, hapus manual dari Galeri"
            Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Video Tersembunyi (${files.size})") }, actions = {
            TextButton({ showSettings = true }) { Text("Setelan") }
            TextButton({ act.unlocked = false }) { Text("Kunci") } }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { act.skipLock = true; picker.launch(arrayOf("video/*")) }) {
                Text("+ Sembunyikan video")
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (files.isEmpty()) Text("Belum ada video.\nTekan tombol + untuk menyembunyikan.",
                Modifier.align(Alignment.Center))
            LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(files, key = { it.name }) { f ->
                    Thumb(f, Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).clickable { selected = f })
                }
            }
            if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }

    if (showSettings) {
        val codeOk = Stealth.codeOk(act)
        AlertDialog(onDismissRequest = { showSettings = false },
            title = { Text("Mode tersembunyi") },
            text = { Text("1. Tes kode: buka aplikasi Telepon, ketik *#*#8888#*#* . Jika aplikasi ini terbuka, tes berhasil.\n\nStatus tes: " +
                (if (codeOk) "✅ berhasil" else "❌ belum") +
                "\n\n2. Setelah tes berhasil, sembunyikan ikon. Aplikasi tidak muncul di menu maupun pencarian; buka lewat kode tadi.") },
            confirmButton = {
                TextButton(enabled = hidden || codeOk, onClick = {
                    Stealth.setHidden(act, !hidden); hidden = !hidden
                }) { Text(if (hidden) "Tampilkan ikon" else "Sembunyikan ikon") }
            },
            dismissButton = { TextButton({ showSettings = false }) { Text("Tutup") } })
    }

    selected?.let { f ->
        AlertDialog(onDismissRequest = { selected = null },
            title = { Text(f.name.substringAfter('_'), maxLines = 2) },
            text = { Text("Pilih tindakan untuk video ini.") },
            confirmButton = { TextButton({ playing = f; selected = null }) { Text("Putar") } },
            dismissButton = {
                Row {
                    TextButton({
                        selected = null
                        scope.launch {
                            withContext(Dispatchers.IO) { runCatching { Vault.restore(act, f) } }
                            files = Vault.list(act)
                            Toast.makeText(act, "Dikembalikan ke Movies/Restored", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Kembalikan") }
                    TextButton({ f.delete(); files = Vault.list(act); selected = null }) {
                        Text("Hapus", color = MaterialTheme.colorScheme.error)
                    }
                }
            })
    }

    playing?.let { f ->
        Dialog({ playing = null }) {
            AndroidView(factory = { c ->
                VideoView(c).apply {
                    setMediaController(MediaController(c).also { it.setAnchorView(this) })
                    setVideoPath(f.path); start()
                }
            }, modifier = Modifier.fillMaxWidth().height(320.dp))
        }
    }
}

@Composable
fun Thumb(f: File, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, f) {
        value = withContext(Dispatchers.IO) {
            runCatching { ThumbnailUtils.createVideoThumbnail(f, Size(320, 320), null) }.getOrNull()
        }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            ?: Text("🎬")
    }
}

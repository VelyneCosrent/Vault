package com.example.videovault

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.os.Bundle
import android.util.Size
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Dark = darkColorScheme(
    primary = Color(0xFF5B9DFF), onPrimary = Color.Black,
    background = Color(0xFF0D1117), surface = Color(0xFF161B22),
    surfaceVariant = Color(0xFF21262D), onSurface = Color(0xFFE6EDF3),
    onSurfaceVariant = Color(0xFF8B949E), error = Color(0xFFFF6B6B)
)

fun fmtSize(b: Long) = if (b >= (1L shl 30)) "%.1f GB".format(b / 1073741824.0) else "%.1f MB".format(b / 1048576.0)

class MainActivity : ComponentActivity() {
    var unlocked by mutableStateOf(false)
    var decoy by mutableStateOf(false)
    var skipLock = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            MaterialTheme(colorScheme = Dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val store = remember { PinStore(this) }
                    if (unlocked) Home(this, store)
                    else PinScreen(store) { d -> Vault.decoy = d; decoy = d; unlocked = true }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); skipLock = false }
    override fun onStop() {
        super.onStop()
        if (!skipLock) { unlocked = false; Vault.decoy = false; decoy = false }
    }
}

@Composable
fun PinScreen(store: PinStore, onOk: (Boolean) -> Unit) {
    val create = remember { !store.hasPin() }
    var first by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val title = when {
        !create -> "Masukkan PIN untuk melanjutkan"
        first == null -> "Buat PIN baru (4–6 angka)"
        else -> "Ulangi PIN"
    }
    fun submit() {
        val now = System.currentTimeMillis()
        if (!create && now < store.lockUntil) { err = "Terkunci, coba lagi ${(store.lockUntil - now) / 1000 + 1} detik"; pin = ""; return }
        if (pin.length < 4) { err = "Minimal 4 angka"; return }
        when {
            !create -> when {
                store.check(pin) -> { store.fails = 0; onOk(false) }
                store.checkDecoy(pin) -> onOk(true)
                else -> {
                    store.fails += 1; pin = ""
                    if (store.fails >= 5) { store.lockUntil = now + 30_000L * (store.fails - 4); err = "Terlalu banyak percobaan. Terkunci sementara." }
                    else err = "PIN salah (${store.fails}/5)"
                }
            }
            first == null -> { first = pin; pin = ""; err = "" }
            first == pin -> { store.set(pin); onOk(false) }
            else -> { err = "PIN tidak sama, ulangi dari awal"; first = null; pin = "" }
        }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), Alignment.Center) {
            Text("⚙", fontSize = 30.sp, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(16.dp))
        Text("System Management", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(6) { i ->
                Box(Modifier.size(12.dp).clip(CircleShape).background(
                    if (i < pin.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))
            }
        }
        Text(err, color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.height(40.dp).padding(top = 12.dp))
        listOf("1","2","3","4","5","6","7","8","9","⌫","0","OK").chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                row.forEach { k ->
                    FilledTonalButton({
                        err = ""
                        when (k) { "⌫" -> pin = pin.dropLast(1); "OK" -> submit(); else -> if (pin.length < 6) pin += k }
                    }, Modifier.padding(vertical = 5.dp).size(72.dp), shape = CircleShape, contentPadding = PaddingValues(0.dp)) {
                        Text(k, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun VaultScreen(act: MainActivity, store: PinStore) {
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(Vault.list(act)) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var playing by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    val labels = listOf("Terbaru", "Nama", "Ukuran")
    fun name(f: File) = f.name.substringAfter('_')
    val shown = files.filter { name(it).contains(query, true) }.let {
        when (sort) { 1 -> it.sortedBy { f -> name(f).lowercase() }; 2 -> it.sortedByDescending { f -> f.length() }; else -> it }
    }
    fun refresh() { files = Vault.list(act) }
    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val failed = withContext(Dispatchers.IO) { uris.count { runCatching { !Vault.hide(act, it) }.getOrDefault(true) } }
            refresh(); busy = false
            toast(if (failed == 0) "${uris.size} video diamankan" else "$failed file asli gagal dihapus otomatis, hapus manual dari Galeri")
        }
    }
    BackHandler(sel.isNotEmpty()) { sel = emptySet() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                title = {
                    Column {
                        Text(if (sel.isEmpty()) "Brankas" else "${sel.size} dipilih", fontWeight = FontWeight.SemiBold)
                        if (sel.isEmpty()) Text("${files.size} file • ${fmtSize(files.sumOf { it.length() })}",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    if (sel.isNotEmpty()) TextButton({ sel = emptySet() }) { Text("Batal") }
                    else {
                        if (!act.decoy) TextButton({ settings = true }) { Text("Setelan") }
                        TextButton({ act.unlocked = false }) { Text("Kunci") }
                    }
                })
        },
        bottomBar = {
            if (sel.isNotEmpty()) Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding().padding(12.dp), Arrangement.SpaceEvenly) {
                Button({
                    busy = true
                    scope.launch {
                        withContext(Dispatchers.IO) { files.filter { it.name in sel }.forEach { runCatching { Vault.restore(act, it) } } }
                        sel = emptySet(); refresh(); busy = false; toast("Dikembalikan ke Movies/Restored")
                    }
                }) { Text("Kembalikan") }
                Button({ confirmDel = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Hapus") }
            }
        },
        floatingActionButton = {
            if (sel.isEmpty()) ExtendedFloatingActionButton(onClick = { act.skipLock = true; picker.launch(arrayOf("video/*")) }) { Text("+ Tambah video") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("Cari nama file") }, shape = RoundedCornerShape(14.dp))
                TextButton({ sort = (sort + 1) % 3 }) { Text("Urut: ${labels[sort]}") }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (shown.isEmpty()) Text(if (files.isEmpty()) "Brankas kosong.\nKetuk “+ Tambah video” untuk mengamankan video."
                    else "Tidak ada hasil.", Modifier.align(Alignment.Center).padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(shown, key = { it.name }) { f ->
                        fun toggle() { sel = if (f.name in sel) sel - f.name else sel + f.name }
                        Thumb(f, f.name in sel, Modifier.aspectRatio(1f).combinedClickable(
                            onClick = { if (sel.isNotEmpty()) toggle() else playing = f }, onLongClick = { toggle() }))
                    }
                }
                if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
            }
        }
    }

    if (settings) SettingsDialog(act, store) { settings = false }

    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false },
        title = { Text("Hapus ${sel.size} video?") }, text = { Text("Video dihapus permanen dan tidak bisa dikembalikan.") },
        confirmButton = { TextButton({
            files.filter { it.name in sel }.forEach { it.delete() }; sel = emptySet(); confirmDel = false; refresh()
        }) { Text("Hapus", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton({ confirmDel = false }) { Text("Batal") } })

    playing?.let { f -> Player("file://${f.path}", emptyMap()) { playing = null } }
}

@Composable
fun SettingsDialog(act: MainActivity, store: PinStore, onClose: () -> Unit) {
    var hidden by remember { mutableStateOf(Stealth.isHidden(act)) }
    var newPin by remember { mutableStateOf("") }
    var hasDecoy by remember { mutableStateOf(store.hasDecoy()) }
    val codeOk = Stealth.codeOk(act)
    fun msg(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    AlertDialog(onDismissRequest = onClose, title = { Text("Setelan") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sembunyikan ikon", fontWeight = FontWeight.SemiBold)
                Text("Tes dulu: ketik *#*#8888#*#* di aplikasi Telepon. Status: " + if (codeOk) "✅ berhasil" else "❌ belum", fontSize = 13.sp)
                Button(enabled = hidden || codeOk, onClick = { Stealth.setHidden(act, !hidden); hidden = !hidden }) {
                    Text(if (hidden) "Tampilkan ikon" else "Sembunyikan ikon")
                }
                HorizontalDivider()
                Text("Keamanan PIN", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(newPin, { v -> if (v.length <= 6 && v.all { it.isDigit() }) newPin = v },
                    label = { Text("PIN baru (4–6 angka)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = newPin.length >= 4, onClick = {
                        if (store.checkDecoy(newPin)) msg("Harus beda dari PIN jebakan") else { store.set(newPin); newPin = ""; msg("PIN diubah") }
                    }) { Text("Ubah PIN") }
                    OutlinedButton(enabled = newPin.length >= 4, onClick = {
                        if (store.check(newPin)) msg("Harus beda dari PIN utama") else { store.setDecoy(newPin); hasDecoy = true; newPin = ""; msg("PIN jebakan aktif") }
                    }) { Text("PIN jebakan") }
                }
                if (hasDecoy) TextButton({ store.clearDecoy(); hasDecoy = false }) { Text("Hapus PIN jebakan") }
                Text("PIN jebakan membuka brankas kosong palsu, berguna jika Anda dipaksa membuka aplikasi.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }, confirmButton = { TextButton(onClose) { Text("Tutup") } })
}

@Composable
fun Thumb(f: File, selected: Boolean, modifier: Modifier) {
    val info by produceState<Pair<Bitmap?, String>>(Pair(null, ""), f) {
        value = withContext(Dispatchers.IO) {
            val bmp = runCatching { ThumbnailUtils.createVideoThumbnail(f, Size(360, 360), null) }.getOrNull()
            val dur = runCatching {
                val r = MediaMetadataRetriever(); r.setDataSource(f.path)
                val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong(); r.release()
                "%d:%02d".format(ms / 60000, ms / 1000 % 60)
            }.getOrDefault("")
            Pair(bmp, dur)
        }
    }
    val shape = RoundedCornerShape(10.dp)
    Box(modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)) {
        info.first?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (info.second.isNotEmpty()) Text(info.second, Modifier.align(Alignment.BottomEnd).padding(4.dp)
            .background(Color(0x99000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp), fontSize = 11.sp, color = Color.White)
        Text(fmtSize(f.length()), Modifier.align(Alignment.TopStart).padding(4.dp)
            .background(Color(0x99000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp), fontSize = 10.sp, color = Color.White)
        if (selected) Box(Modifier.fillMaxSize().background(Color(0x665B9DFF)).border(3.dp, MaterialTheme.colorScheme.primary, shape),
            Alignment.Center) { Text("✓", fontSize = 28.sp, color = Color.White) }
    }
}

package com.example.videovault

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.*
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

class Media(val url: String, val name: String, val ref: String, val ua: String, val cookie: String) {
    fun headers() = mapOf("User-Agent" to ua, "Referer" to ref, "Cookie" to cookie).filterValues { it.isNotBlank() }
}
class Dl(val name: String) {
    var pct by mutableIntStateOf(0)
    var state by mutableIntStateOf(0) // 0 berjalan, 1 selesai, 2 gagal
}

object BrowserState {
    var web: WebView? = null
    var curUrl by mutableStateOf("")
    var prog by mutableIntStateOf(100)
    var auto by mutableStateOf(true)
    var autoOpen by mutableStateOf<Media?>(null)
    val found = mutableStateListOf<Media>()
    val dls = mutableStateListOf<Dl>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val exts = listOf(".mp4", ".webm", ".mkv", ".mov", ".m4v", ".3gp", ".m3u8")

    fun create(a: MainActivity) = WebView(a).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                sniff(a, v, r.url.toString()); return null
            }
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { curUrl = u; found.clear() }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { prog = p }
        }
        loadUrl("https://www.google.com")
    }

    private fun sniff(a: MainActivity, v: WebView, url: String) {
        val ext = exts.firstOrNull { url.substringBefore('?').lowercase().endsWith(it) } ?: return
        a.runOnUiThread {
            if (found.none { it.url == url }) {
                val t = (v.title ?: "video").replace(Regex("[^\\p{L}\\p{N} ]"), "").trim().take(40).ifEmpty { "video" }
                val m = Media(url, t + (if (ext == ".m3u8") ".ts" else ext), v.url ?: "",
                    v.settings.userAgentString ?: "", CookieManager.getInstance().getCookie(url) ?: "")
                found.add(m)
                if (auto) autoOpen = m
            }
        }
    }

    fun download(c: Context, m: Media) {
        val dl = Dl(m.name); dls.add(0, dl)
        val dest = File(Vault.dir(c), "${System.currentTimeMillis()}_${m.name}")
        scope.launch {
            val ok = runCatching {
                if (m.url.substringBefore('?').lowercase().endsWith(".m3u8")) hls(m, dest, dl) else http(m, dest, dl)
            }.isSuccess
            if (!ok) dest.delete()
            dl.state = if (ok) 1 else 2
        }
    }

    private fun open(m: Media, url: String) = (URL(url).openConnection() as HttpURLConnection).apply {
        m.headers().forEach { (k, v) -> setRequestProperty(k, v) }
        connectTimeout = 15000; readTimeout = 30000
    }

    private fun http(m: Media, dest: File, dl: Dl) {
        val c = open(m, m.url)
        if (c.responseCode >= 400 || c.contentType?.startsWith("text/") == true) error("bukan video")
        val total = c.contentLengthLong
        c.inputStream.use { i -> dest.outputStream().use { o ->
            val buf = ByteArray(65536); var n: Int; var sum = 0L
            while (i.read(buf).also { n = it } > 0) {
                o.write(buf, 0, n); sum += n
                if (total > 0) dl.pct = (sum * 100 / total).toInt()
            }
        } }
    }

    // HLS tanpa enkripsi: unduh semua segmen lalu gabungkan
    private fun hls(m: Media, dest: File, dl: Dl) {
        fun get(u: String) = open(m, u).inputStream.bufferedReader().readText()
        var base = m.url; var text = get(base)
        if ("#EXT-X-STREAM-INF" in text) {
            base = URI(base).resolve(text.lines().last { it.isNotBlank() && !it.startsWith("#") }.trim()).toString()
            text = get(base)
        }
        if ("#EXT-X-KEY" in text) error("terenkripsi")
        val segs = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        dest.outputStream().use { o -> segs.forEachIndexed { i, s ->
            open(m, URI(base).resolve(s).toString()).inputStream.use { it.copyTo(o) }
            dl.pct = (i + 1) * 100 / segs.size
        } }
    }
}

@Composable
fun Home(act: MainActivity, store: PinStore) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("🔒") }, label = { Text("Brankas") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("🌐") }, label = { Text("Browser") })
            }
        }) { pad -> Box(Modifier.padding(pad)) { if (tab == 0) VaultScreen(act, store) else BrowserScreen(act) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(act: MainActivity) {
    val ctx = LocalContext.current
    val web = remember { BrowserState.web ?: BrowserState.create(act).also { BrowserState.web = it } }
    var addr by remember(BrowserState.curUrl) { mutableStateOf(BrowserState.curUrl) }
    var menu by remember { mutableStateOf(false) }
    var sheet by remember { mutableStateOf(false) }
    var play by remember { mutableStateOf<Media?>(null) }
    val found = BrowserState.found
    val dls = BrowserState.dls
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun go() {
        val t = addr.trim()
        web.loadUrl(when {
            t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(t)
            t.startsWith("http") -> t
            else -> "https://$t"
        })
    }
    BackHandler(web.canGoBack()) { web.goBack() }
    LaunchedEffect(BrowserState.autoOpen) {
        BrowserState.autoOpen?.let {
            if (play == null) {
                play = it
                web.evaluateJavascript("document.querySelectorAll('video').forEach(function(v){v.pause()})", null)
            }
            BrowserState.autoOpen = null
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton({ if (web.canGoBack()) web.goBack() }) { Text("←", fontSize = 20.sp) }
            OutlinedTextField(addr, { addr = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(24.dp),
                placeholder = { Text("Cari atau ketik alamat") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { go() }))
            Box {
                TextButton({ menu = true }) { Text("⋮", fontSize = 20.sp) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Muat ulang") }, { web.reload(); menu = false })
                    DropdownMenuItem({ Text("Maju") }, { web.goForward(); menu = false })
                    DropdownMenuItem({ Text("Buka otomatis di pemutar: " + if (BrowserState.auto) "ON" else "OFF") },
                        { BrowserState.auto = !BrowserState.auto; menu = false })
                    DropdownMenuItem({ Text("Hapus riwayat & cookie") }, {
                        web.clearHistory(); web.clearCache(true); CookieManager.getInstance().removeAllCookies(null)
                        toast("Data browser dihapus"); menu = false
                    })
                }
            }
        }
        if (BrowserState.prog < 100) LinearProgressIndicator(progress = { BrowserState.prog / 100f }, modifier = Modifier.fillMaxWidth())
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { (web.parent as? ViewGroup)?.removeView(web); web }, modifier = Modifier.fillMaxSize())
            if (found.isNotEmpty() || dls.isNotEmpty())
                ExtendedFloatingActionButton(onClick = { sheet = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                    Text("⬇ Video (${found.size})")
                }
        }
    }

    if (sheet) AlertDialog(onDismissRequest = { sheet = false }, title = { Text("Video & unduhan") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (found.isNotEmpty()) item { Text("Terdeteksi di halaman", fontWeight = FontWeight.SemiBold) }
                items(found) { m ->
                    Column {
                        Text(m.name, maxLines = 2, fontSize = 14.sp)
                        Text(runCatching { URI(m.url).host }.getOrNull() ?: "", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            TextButton({ play = m; sheet = false }) { Text("▶ Putar") }
                            TextButton({ BrowserState.download(ctx, m); toast("Mengunduh ke brankas…") }) { Text("⬇ Unduh") }
                        }
                    }
                }
                if (dls.isNotEmpty()) item { HorizontalDivider(); Text("Unduhan ke brankas", fontWeight = FontWeight.SemiBold) }
                items(dls) { d ->
                    Column {
                        Text(d.name, maxLines = 1, fontSize = 13.sp)
                        when (d.state) {
                            0 -> LinearProgressIndicator(progress = { d.pct / 100f }, modifier = Modifier.fillMaxWidth())
                            1 -> Text("✅ Tersimpan di brankas", fontSize = 12.sp)
                            else -> Text("❌ Gagal (mungkin diproteksi/terenkripsi)", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }, confirmButton = { TextButton({ sheet = false }) { Text("Tutup") } })

    play?.let { m -> Player(m.url, m.headers(), { BrowserState.download(ctx, m); toast("Mengunduh ke brankas…") }) { play = null } }
}

@Composable
fun Player(src: String, headers: Map<String, String>, onDownload: (() -> Unit)? = null, onClose: () -> Unit) {
    Dialog(onClose, DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { c ->
                FrameLayout(c).apply {
                    val vv = VideoView(c)
                    addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
                    vv.setMediaController(MediaController(c).also { it.setAnchorView(this) })
                    vv.setOnErrorListener { _, _, _ ->
                        Toast.makeText(c, "Video tidak bisa diputar", Toast.LENGTH_SHORT).show(); true }
                    vv.setVideoURI(Uri.parse(src), headers); vv.start()
                }
            }, modifier = Modifier.fillMaxSize())
            Row(Modifier.align(Alignment.TopEnd).statusBarsPadding()) {
                onDownload?.let { TextButton(it) { Text("⬇ Unduh", color = Color.White) } }
                TextButton(onClose) { Text("Tutup ✕", color = Color.White) }
            }
        }
    }
}
